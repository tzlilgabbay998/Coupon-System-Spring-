package couponPhase2.Application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CouponSystemPhase2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
