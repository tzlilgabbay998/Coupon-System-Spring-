package couponPhase2.Exception;

public class CouponSystemException extends Exception {

	private static final long serialVersionUID = 1L;

	public CouponSystemException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CouponSystemException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public CouponSystemException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CouponSystemException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CouponSystemException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
